Help mode
===

```
$ tir
```
or
```
$ tir -h
```

[back to Contents](contents.md)
