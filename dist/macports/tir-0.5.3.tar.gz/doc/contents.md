Contents
===
* [Install](install.md)
* [Syntax](syntax.md)
* [Help mode](help-mode.md)
* Case examples
  * [1. Into a HTML file, inserting HTML files](example1.md)
  * [2. Multi-File & Nesting](example2.md)
  * [3. Inserting config values](example3.md)
* [Deference of `sed` command](deference-of-sed-command.md)

-[Note](note.md)

[back to README](../README.md)
