ヘルプモード
===

```
$ tir
```
or
```
$ tir -h
```

[目次に戻る](contents_jp.md)
