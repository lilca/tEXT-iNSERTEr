インストール
===
```
$ sudo make install
```

[目次に戻る](contents_jp.md)
